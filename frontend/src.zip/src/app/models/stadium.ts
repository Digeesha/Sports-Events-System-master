export interface Stadium {
  id?: number;
  name: string;
  capacity: number;
}
