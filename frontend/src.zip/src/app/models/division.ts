export interface Division {
    id?: number;
    name?: string;
  }
  