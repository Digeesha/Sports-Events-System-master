export interface City {
  id?: number;
  name: string;
}
